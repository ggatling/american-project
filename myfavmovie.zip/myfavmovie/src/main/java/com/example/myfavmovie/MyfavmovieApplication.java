package com.example.myfavmovie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyfavmovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyfavmovieApplication.class, args);
	}

}
